// PM25Calibration.H - Implementasi library untuk kalibrasi sensor PM2.5
// Created by [M. Iqbal Mutawaqil], [03-03-2025]

#ifndef PM25CALIBRATION_H
#define PM25CALIBRATION_H

#include "Arduino.h"

class PM25Calibration {
  public:
    PM25Calibration();  // Konstruktor
    float convertToReferenceValue(float rawValue);
    
    // Fungsi untuk mendapatkan ukuran tabel
    int getRawTableSize();  // Mendapatkan ukuran rawTable
    int getRefTableSize();  // Mendapatkan ukuran refTable

  private:
    static const int rawTableSize = 915;   // Jumlah data raw PM2.5
    static const int refTableSize = 1000;  // Jumlah data referensi PM2.5

    static const float rawPM25Table[rawTableSize];
    static const float refPM25Table[refTableSize];
};

#endif
